# Poner HandShake en un servidor gratis de Oracle

Con esto, la app y el servidor viven en tu propia máquina de Oracle Cloud ("Always Free"):
cuentas por código, amigos, solicitudes, chat directo y de grupo, mensajes guardados si el amigo está
desconectado, presencia (🟢 en línea), retos a duelos y salas con código de 5 letras + 3 números.

Tiempo: unos 30–40 minutos la primera vez. Hay cosas que solo puedes hacer tú (crear la cuenta, la tarjeta, la máquina).

## 1. Cuenta de Oracle Cloud
1. Entra en https://www.oracle.com/cloud/free/ y pulsa **Start for free**.
2. Te pedirá una tarjeta solo para verificar tu identidad. Los recursos "Always Free" no se cobran; usa solo esos.
3. Elige la **región de origen** con cuidado: no se puede cambiar después. Escoge una europea (por ejemplo Frankfurt o Madrid).

## 2. Crear la máquina (instancia)
1. Menú → **Compute → Instances → Create instance**.
2. **Image**: Ubuntu 22.04 o 24.04.
3. **Shape**: elige una marcada "Always Free-eligible":
   - `VM.Standard.E2.1.Micro` (AMD, 1 GB): sobra para esto y suele haber disponibilidad.
   - `VM.Standard.A1.Flex` (ARM): más potente, pero a veces dice "Out of capacity". Si pasa, usa la Micro.
4. **Networking**: deja marcada la **IP pública**.
5. **SSH keys**: pulsa *Save private key* y guarda el archivo (lo necesitas para entrar). No lo pierdas ni lo compartas.
6. Pulsa **Create**. Cuando esté en verde ("Running"), apunta su **Public IP address**.

## 3. Abrir los puertos 80 y 443 en Oracle
1. En la instancia → pulsa el enlace de la **Subnet** → **Security Lists** → la de "Default…".
2. **Add Ingress Rules** (dos reglas): Source CIDR `0.0.0.0/0`, IP Protocol `TCP`, Destination Port `80`; y otra igual con `443`.

(El script del paso 6 abre también el cortafuegos interno de la máquina.)

## 4. Un nombre gratis (necesario para el candado HTTPS)
Los móviles solo dejan conectar con `wss://` si hay certificado, y el certificado necesita un nombre.
1. Entra en https://www.duckdns.org (con tu cuenta de Google o GitHub).
2. Crea un subdominio, por ejemplo `handshake-julen` → será `handshake-julen.duckdns.org`.
3. En **current ip** pon la IP pública de tu máquina y pulsa **update ip**.

## 5. Entrar en la máquina y subir la app
En tu ordenador (PowerShell, Terminal o similar), en la carpeta donde está la clave y `handshake.zip`:

```
ssh -i clave.key ubuntu@IP_PUBLICA
```
(si te dice que la clave tiene permisos demasiado abiertos: `chmod 600 clave.key`). Desde otra ventana del ordenador:

```
scp -i clave.key handshake.zip ubuntu@IP_PUBLICA:~
```

## 6. Instalar (un solo comando)
Ya dentro de la máquina:

```
sudo apt-get install -y unzip
unzip -o handshake.zip -d handshake
cd handshake
sudo bash server/setup.sh handshake-julen.duckdns.org
```
Cambia el dominio por el tuyo. El script instala Node.js y Caddy (el que pone el HTTPS solo), copia la app,
crea el servicio que se arranca solo al encender la máquina y activa una copia de seguridad diaria de los datos.

## 7. Probar
- Abre `https://handshake-julen.duckdns.org` en el móvil: es la app, servida desde tu máquina.
- **Ajustes → Servidor** debe poner "Conectado ✅". A partir de ahí, añadir amigos con su código, el chat y los retos van por tu servidor.
- Tus amigos abren esa misma dirección (puedes añadirla a la pantalla de inicio desde el navegador).

Si abres la app desde otro sitio (otro hosting), en **Ajustes → Servidor** pega `https://handshake-julen.duckdns.org` y pulsa *Guardar y conectar*.
También puedes fijarlo en `config.js` (`serverUrl`).

## Mantenimiento
- Ver registros: `sudo journalctl -u handshake -f`
- Reiniciar: `sudo systemctl restart handshake`
- Actualizar la app: sube un `handshake.zip` nuevo y repite el paso 6 (los datos se conservan en `/var/lib/handshake`).
- Copias: `/var/backups/handshake/` (una al día, se guardan 14).

## Cosas que debes saber
- **Privacidad**: los mensajes y las cuentas se guardan en un archivo (`/var/lib/handshake/db.json`) **sin cifrar de extremo a extremo**; quien administre la máquina (tú) podría leerlos. No uses esto para prometer privacidad total a otras personas sin decírselo.
- **Sin contraseña**: cada móvil guarda una clave secreta aleatoria. Si borras los datos del navegador, pierdes esa cuenta y tendrás un código nuevo. Una cuenta = un dispositivo por ahora.
- **Eventos del chat** (encuestas, dados, ruleta…): viajan por el servidor, pero los rollos que dan se calculan en cada móvil (no hay comprobación contra trampas).
- **Oracle** puede recuperar instancias gratuitas que estén casi sin uso durante días y puede cambiar sus condiciones: revisa su página de Always Free de vez en cuando.
- **Duelos online**: los datos de la partida van directos entre los dos móviles (WebRTC). Con algunas redes (datos móviles de ciertas operadoras, wifis de empresa) puede no conectar sin un servidor TURN; no está incluido.
- **Seguridad**: hay límites de mensajes por segundo, tamaño, amigos y grupos. No hay moderación ni sistema de bloqueo.
