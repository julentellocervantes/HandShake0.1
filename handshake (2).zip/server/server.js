'use strict';
/* Servidor de HandShake (Node.js + WebSocket).
   - /ws       Cuentas por código de amigo, amigos, solicitudes, chats directos y de grupo,
               presencia e invitaciones a duelos. Los mensajes para alguien desconectado se
               guardan y se entregan cuando vuelve a conectarse.
   - /peerjs   Salas de duelo con código corto (5 letras + 3 números). Solo reenvía el
               "apretón de manos" WebRTC; la partida va directa entre los dos móviles.
   - /health   Comprobación de estado.
   - Sirve además los ficheros de la app (index.html, app.js...) para tener todo en un mismo sitio.
   Sin contraseñas ni correos: cada dispositivo genera un secreto aleatorio que lo identifica. */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');

const PORT = Number(process.env.PORT) || 8080;
const HOST = process.env.HOST || '0.0.0.0';
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'data', 'db.json');
const STATIC_DIR = process.env.STATIC_DIR === undefined ? path.join(__dirname, '..') : process.env.STATIC_DIR;
const ORIGINS = (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
const LIM = { friends: 200, groups: 40, groupSize: 30, inbox: 500, perIp: 25 };

const CODE_RE = /^\d{4}[A-Z]{3}$/;
const ROOM_RE = /^[A-Z]{5}\d{3}$/;
const PEER_RE = /^jerkon-[A-Za-z0-9]{1,12}$/;
const GID_RE = /^[A-Za-z0-9_-]{4,40}$/;
const TOKEN_RE = /^[0-9a-f]{32,128}$/;
const MSGID_RE = /^[A-Za-z0-9_-]{1,40}$/;

/* ---------- Base de datos (un JSON, guardado de forma atómica) ---------- */
let db = { users: {}, friends: {}, reqs: [], groups: {}, inbox: {}, seq: {} };
try { db = Object.assign(db, JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'))); } catch { /* base nueva */ }
let dirty = false, timer = null;
function persist() { dirty = true; if (!timer) timer = setTimeout(flush, 400); }
function flush() {
  timer = null;
  if (!dirty) return;
  dirty = false;
  try {
    fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
    const tmp = DATA_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(db));
    fs.renameSync(tmp, DATA_FILE);
  } catch (e) { console.error('No se pudo guardar:', e.message); dirty = true; }
}
function shutdown() { flush(); process.exit(0); }
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

/* ---------- Utilidades ---------- */
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const same = (a, b) => { const x = Buffer.from(a), y = Buffer.from(b); return x.length === y.length && crypto.timingSafeEqual(x, y); };
const cleanName = s => String(s || '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 24);
const send = (ws, o) => { if (ws.readyState === 1) ws.send(JSON.stringify(o)); };
const online = new Map();       // código -> Set<ws>
const nameOf = c => (db.users[c] || {}).name || 'Alguien';
const namesOf = list => Object.fromEntries(list.map(c => [c, nameOf(c)]));
const friendsOf = c => db.friends[c] || (db.friends[c] = []);
const areFriends = (a, b) => friendsOf(a).includes(b);

function emit(code, o) { const s = online.get(code); if (s) for (const w of s) send(w, o); }
// Mensaje que debe llegar sí o sí: se guarda hasta que el cliente lo confirme
function queue(code, o) {
  const n = (db.seq[code] = (db.seq[code] || 0) + 1);
  const it = Object.assign({ n }, o);
  const box = db.inbox[code] || (db.inbox[code] = []);
  box.push(it);
  while (box.length > LIM.inbox) box.shift();
  persist();
  emit(code, it);
}

const hits = new Map();
function rate(key, max, ms) {
  const now = Date.now();
  const a = (hits.get(key) || []).filter(t => now - t < ms);
  if (a.length >= max) { hits.set(key, a); return false; }
  a.push(now); hits.set(key, a); return true;
}
setInterval(() => { const now = Date.now(); for (const [k, a] of hits) if (!a.length || now - a[a.length - 1] > 3600e3) hits.delete(k); }, 600e3).unref();

const EV_KINDS = ['reto', 'encuesta', 'pulso', 'meta', 'dado', 'ruleta', 'prediccion', 'semaforo'];
// Eventos de chat: 'launch' crea el evento en el chat y 'act' es la participación de quien lo envía
function cleanEv(p) {
  if (!p || typeof p !== 'object') return null;
  if (p.op === 'act') {
    const v = Math.floor(Number(p.v));
    if (!MSGID_RE.test(String(p.evId)) || !(v >= 0 && v <= 10)) return null;
    return { op: 'act', evId: String(p.evId), v };
  }
  const e = p.ev;
  if (p.op !== 'launch' || !e || !EV_KINDS.includes(e.kind) || !MSGID_RE.test(String(e.id))) return null;
  const dur = Math.floor(Number(e.dur));
  if (!(dur >= 1 && dur <= 1440)) return null;
  const o = { id: String(e.id), kind: e.kind, dur };
  if (e.kind === 'encuesta') {
    if (!Array.isArray(e.opts)) return null;
    o.opts = e.opts.slice(0, 4).map(x => String(x).slice(0, 60)).filter(Boolean);
    if (o.opts.length < 2) return null;
  }
  if (e.kind === 'encuesta' || e.kind === 'semaforo') { o.q = String(e.q || '').slice(0, 200); if (!o.q) return null; }
  if (e.kind === 'meta') { o.goal = Math.floor(Number(e.goal)); if (!(o.goal >= 1 && o.goal <= 50)) return null; }
  if (e.kind === 'prediccion') o.coin = Number(e.coin) === 1 ? 1 : 0;
  return { op: 'launch', ev: o };
}

function cleanMsg(m) {
  if (!m || typeof m !== 'object') return null;
  if (m.type === 'text') {
    const text = String(m.text || '').slice(0, 1000);
    return text.trim() ? { type: 'text', text } : null;
  }
  if (m.type === 'event') {
    const mood = Math.floor(Number(m.mood) || 0);
    if (mood < 0 || mood > 5) return null;
    const o = { type: 'event', mood };
    if (m.note) o.note = String(m.note).slice(0, 500);
    if (m.fx) o.fx = String(m.fx).slice(0, 20);
    return o;
  }
  return null;
}

/* ---------- Cuentas, amigos y chat ---------- */
function ready(code) {
  return {
    t: 'ready',
    me: { code, name: nameOf(code) },
    friends: friendsOf(code).map(c => ({ code: c, name: nameOf(c) })),
    inReq: db.reqs.filter(r => r.to === code).map(r => ({ code: r.from, name: nameOf(r.from), ts: r.ts })),
    outReq: db.reqs.filter(r => r.from === code).map(r => ({ code: r.to, ts: r.ts })),
    groups: Object.entries(db.groups).filter(([, g]) => g.members.includes(code)).map(([gid, g]) => ({ gid, name: g.name, members: g.members, names: namesOf(g.members) })),
    online: friendsOf(code).filter(c => online.has(c)),
    seq: db.seq[code] || 0,
    now: Date.now()
  };
}

function presence(code, on) {
  for (const f of friendsOf(code)) emit(f, { t: 'pres', code, on });
}

const H = {
  name(ws, m) {
    const name = cleanName(m.name);
    if (!name) return;
    db.users[ws.code].name = name;
    persist();
    for (const f of friendsOf(ws.code)) emit(f, { t: 'fname', code: ws.code, name });
  },
  req(ws, m) {
    const me = ws.code, to = String(m.to || '');
    if (!CODE_RE.test(to) || to === me) return fail(ws, 'req', 'code');
    if (!db.users[to]) return fail(ws, 'req', 'no-user');
    if (areFriends(me, to)) return fail(ws, 'req', 'friends');
    if (db.reqs.some(r => r.from === me && r.to === to)) return fail(ws, 'req', 'pending');
    if (friendsOf(me).length >= LIM.friends) return fail(ws, 'req', 'full');
    if (db.reqs.filter(r => r.from === me).length >= 50) return fail(ws, 'req', 'many');
    // Si esa persona ya te había escrito, se aceptan mutuamente
    if (db.reqs.some(r => r.from === to && r.to === me)) return H.accept(ws, { from: to });
    db.reqs.push({ from: me, to, ts: Date.now() });
    persist();
    send(ws, { t: 'ok', re: 'req', to, name: nameOf(to) });
    queue(to, { t: 'req', from: me, name: nameOf(me), ts: Date.now() });
  },
  accept(ws, m) {
    const me = ws.code, from = String(m.from || '');
    const i = db.reqs.findIndex(r => r.from === from && r.to === me);
    if (i < 0) return fail(ws, 'accept', 'none');
    db.reqs.splice(i, 1);
    if (!areFriends(me, from)) { friendsOf(me).push(from); friendsOf(from).push(me); }
    persist();
    emit(me, { t: 'accepted', code: from, name: nameOf(from), online: online.has(from) });
    queue(from, { t: 'accepted', code: me, name: nameOf(me), online: online.has(me) });
  },
  reject(ws, m) {
    const me = ws.code, from = String(m.from || '');
    const i = db.reqs.findIndex(r => r.from === from && r.to === me);
    if (i < 0) return;
    db.reqs.splice(i, 1);
    persist();
    queue(from, { t: 'rejected', code: me });
  },
  cancel(ws, m) {
    const me = ws.code, to = String(m.to || '');
    const i = db.reqs.findIndex(r => r.from === me && r.to === to);
    if (i < 0) return;
    db.reqs.splice(i, 1);
    persist();
    queue(to, { t: 'cancelled', from: me });
  },
  unfriend(ws, m) {
    const me = ws.code, c = String(m.code || '');
    if (!areFriends(me, c)) return;
    db.friends[me] = friendsOf(me).filter(x => x !== c);
    db.friends[c] = friendsOf(c).filter(x => x !== me);
    persist();
    queue(c, { t: 'unfriended', code: me });
  },
  dm(ws, m) {
    const me = ws.code, to = String(m.to || '');
    const body = cleanMsg(m.m);
    if (!areFriends(me, to) || !body || !MSGID_RE.test(String(m.id))) return fail(ws, 'dm', 'invalid', m.id);
    queue(to, { t: 'dm', from: me, id: m.id, m: body, ts: Date.now() });
    send(ws, { t: 'sent', id: m.id });
  },
  gnew(ws, m) {
    const me = ws.code;
    const gid = String(m.gid || '');
    const name = cleanName(m.name);
    const members = [...new Set((Array.isArray(m.members) ? m.members : []).map(String))].filter(c => c !== me);
    if (!GID_RE.test(gid) || db.groups[gid] || !name || !members.length || members.length >= LIM.groupSize) return fail(ws, 'gnew', 'invalid');
    if (!members.every(c => areFriends(me, c))) return fail(ws, 'gnew', 'not-friends');
    if (Object.values(db.groups).filter(g => g.members.includes(me)).length >= LIM.groups) return fail(ws, 'gnew', 'full');
    const all = [me, ...members];
    db.groups[gid] = { name, members: all, by: me, created: Date.now() };
    persist();
    for (const c of members) queue(c, { t: 'group', gid, name, members: all, names: namesOf(all), by: me });
    send(ws, { t: 'ok', re: 'gnew', gid });
  },
  gm(ws, m) {
    const me = ws.code, g = db.groups[String(m.gid)];
    const body = cleanMsg(m.m);
    if (!g || !g.members.includes(me) || !body || !MSGID_RE.test(String(m.id))) return fail(ws, 'gm', 'invalid', m.id);
    const ts = Date.now();
    for (const c of g.members) if (c !== me) queue(c, { t: 'gm', gid: m.gid, from: me, id: m.id, m: body, ts });
    send(ws, { t: 'sent', id: m.id });
  },
  evt(ws, m) {
    const me = ws.code, p = cleanEv(m.p);
    if (!p) return fail(ws, 'evt', 'invalid');
    const ts = Date.now();
    if (m.gid !== undefined) {
      const g = db.groups[String(m.gid)];
      if (!g || !g.members.includes(me)) return fail(ws, 'evt', 'invalid');
      for (const c of g.members) if (c !== me) queue(c, { t: 'evt', from: me, gid: m.gid, p, ts });
    } else {
      const to = String(m.to || '');
      if (!areFriends(me, to)) return fail(ws, 'evt', 'invalid');
      queue(to, { t: 'evt', from: me, p, ts });
    }
  },
  gleave(ws, m) {
    const me = ws.code, gid = String(m.gid || ''), g = db.groups[gid];
    if (!g || !g.members.includes(me)) return;
    g.members = g.members.filter(c => c !== me);
    if (g.members.length < 2) {
      for (const c of g.members) queue(c, { t: 'gleft', gid, code: me, closed: true });
      delete db.groups[gid];
    } else for (const c of g.members) queue(c, { t: 'gleft', gid, code: me });
    persist();
  },
  // Invitaciones a un duelo: solo se entregan si el amigo está conectado en ese momento
  inv(ws, m) {
    const me = ws.code, to = String(m.to || '');
    if (!areFriends(me, to) || !ROOM_RE.test(String(m.room)) || !MSGID_RE.test(String(m.id))) return fail(ws, 'inv', 'invalid', m.id);
    if (!online.has(to)) return send(ws, { t: 'invr', id: m.id, from: to, ok: false, why: 'offline' });
    emit(to, { t: 'inv', id: m.id, from: me, name: nameOf(me), game: String(m.game || '').slice(0, 20), room: m.room, ts: Date.now() });
  },
  invr(ws, m) {
    const me = ws.code, to = String(m.to || '');
    if (!areFriends(me, to)) return;
    emit(to, { t: 'invr', id: String(m.id || '').slice(0, 40), from: me, ok: !!m.ok, why: m.ok ? undefined : 'declined' });
  },
  ack(ws, m) {
    const n = Number(m.n) || 0;
    const box = db.inbox[ws.code];
    if (!box) return;
    db.inbox[ws.code] = box.filter(it => it.n > n);
    persist();
  },
  ping(ws) { send(ws, { t: 'pong' }); }
};
function fail(ws, re, why, id) { send(ws, { t: 'err', re, why, id }); }

function onApp(ws, ip) {
  ws.code = null;
  const bucket = { n: 40, t: Date.now() };
  ws.on('message', raw => {
    // 10 mensajes por segundo de media, con ráfagas de 40
    const now = Date.now();
    bucket.n = Math.min(40, bucket.n + (now - bucket.t) / 100); bucket.t = now;
    if (--bucket.n < 0) { ws.close(1008, 'rate'); return; }
    let m;
    try { m = JSON.parse(raw.toString()); } catch { return; }
    if (!m || typeof m.t !== 'string') return;

    if (!ws.code) {
      if (m.t !== 'hello') return;
      const code = String(m.code || ''), token = String(m.token || '');
      if (!CODE_RE.test(code) || !TOKEN_RE.test(token)) { send(ws, { t: 'err', re: 'hello', why: 'format' }); return ws.close(); }
      if (!rate('hello:' + ip, 40, 600e3)) { send(ws, { t: 'err', re: 'hello', why: 'busy' }); return ws.close(); }
      let u = db.users[code];
      if (!u) {
        if (!rate('reg:' + ip, 15, 3600e3)) { send(ws, { t: 'err', re: 'hello', why: 'busy' }); return ws.close(); }
        const name = cleanName(m.name) || 'Yo';
        u = db.users[code] = { name, hash: sha(token), created: Date.now() };
        friendsOf(code);
        persist();
      } else if (!same(u.hash, sha(token))) {
        send(ws, { t: 'err', re: 'hello', why: 'taken' });
        return ws.close();
      } else {
        const name = cleanName(m.name);
        if (name && name !== u.name) { u.name = name; persist(); for (const f of friendsOf(code)) emit(f, { t: 'fname', code, name }); }
      }
      ws.code = code;
      const first = !online.has(code);
      if (first) online.set(code, new Set());
      online.get(code).add(ws);
      send(ws, ready(code));
      for (const it of db.inbox[code] || []) send(ws, it);
      if (first) presence(code, true);
      return;
    }
    const h = H[m.t];
    if (h) h(ws, m);
  });
  ws.on('close', () => {
    if (!ws.code) return;
    const s = online.get(ws.code);
    if (!s) return;
    s.delete(ws);
    if (!s.size) { online.delete(ws.code); presence(ws.code, false); }
  });
}

/* ---------- Salas de duelo (protocolo de señalización compatible con PeerJS) ---------- */
const peers = new Map();
function onPeer(ws, url, ip) {
  const id = url.searchParams.get('id') || '';
  if (!PEER_RE.test(id)) return ws.close(1008, 'id');
  if (peers.has(id)) { send(ws, { type: 'ID-TAKEN', payload: { msg: 'ID is taken' } }); return ws.close(); }
  if (!rate('peer:' + ip, 60, 600e3)) return ws.close(1008, 'rate');
  peers.set(id, ws);
  send(ws, { type: 'OPEN' });
  const bucket = { n: 30, t: Date.now() };
  // Una sala sin pareja caduca a los 10 minutos
  const life = setTimeout(() => ws.close(), 10 * 60e3);
  ws.on('message', raw => {
    const now = Date.now();
    bucket.n = Math.min(30, bucket.n + (now - bucket.t) / 200); bucket.t = now;
    if (--bucket.n < 0) return ws.close(1008, 'rate');
    let m;
    try { m = JSON.parse(raw.toString()); } catch { return; }
    if (!m || typeof m.type !== 'string') return;
    if (m.type === 'HEARTBEAT') return;
    if (!['OFFER', 'ANSWER', 'CANDIDATE'].includes(m.type) || !PEER_RE.test(String(m.dst))) return;
    const to = peers.get(m.dst);
    if (!to) return send(ws, { type: 'EXPIRE', src: m.dst });
    send(to, { type: m.type, src: id, dst: m.dst, payload: m.payload });
  });
  ws.on('close', () => { clearTimeout(life); if (peers.get(id) === ws) peers.delete(id); });
}

/* ---------- HTTP + enrutado de WebSocket ---------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json' };
const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  const headers = { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer' };
  if (url.pathname === '/health') {
    res.writeHead(200, Object.assign({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, headers));
    return res.end(JSON.stringify({ app: 'jerkon', ok: true, users: Object.keys(db.users).length, online: online.size }));
  }
  if (!STATIC_DIR || req.method !== 'GET') { res.writeHead(404, headers); return res.end('No encontrado'); }
  let name = decodeURIComponent(url.pathname).slice(1) || 'index.html';
  const ext = path.extname(name).toLowerCase();
  // Solo ficheros sueltos de la carpeta de la app, nunca subcarpetas (server/, data/...)
  if (name.includes('/') || name.includes('\\') || name.startsWith('.') || !MIME[ext] || name === 'package.json') { res.writeHead(404, headers); return res.end('No encontrado'); }
  fs.readFile(path.join(STATIC_DIR, name), (err, buf) => {
    if (err) { res.writeHead(404, headers); return res.end('No encontrado'); }
    res.writeHead(200, Object.assign({ 'Content-Type': MIME[ext], 'Cache-Control': 'no-cache' }, headers));
    res.end(buf);
  });
});

const wss = new WebSocketServer({ noServer: true, maxPayload: 16 * 1024 });
const conns = new Map();
server.on('upgrade', (req, socket, head) => {
  const url = new URL(req.url, 'http://x');
  const origin = req.headers.origin;
  const ip = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
  if (ORIGINS.length && origin && !ORIGINS.includes(origin)) { socket.destroy(); return; }
  if ((conns.get(ip) || 0) >= LIM.perIp) { socket.destroy(); return; }
  const mode = url.pathname === '/ws' ? 'app' : url.pathname === '/peerjs' ? 'peer' : null;
  if (!mode) { socket.destroy(); return; }
  wss.handleUpgrade(req, socket, head, ws => {
    conns.set(ip, (conns.get(ip) || 0) + 1);
    ws.on('close', () => { const n = (conns.get(ip) || 1) - 1; if (n) conns.set(ip, n); else conns.delete(ip); });
    ws.on('error', () => {});
    ws.isAlive = true;
    ws.on('pong', () => { ws.isAlive = true; });
    if (mode === 'app') onApp(ws, ip); else onPeer(ws, url, ip);
  });
});
// Limpia conexiones muertas (móvil que pierde la cobertura sin cerrar)
setInterval(() => { for (const ws of wss.clients) { if (!ws.isAlive) { ws.terminate(); continue; } ws.isAlive = false; try { ws.ping(); } catch { /* ya cerrada */ } } }, 30e3).unref();

if (require.main === module) {
  server.listen(PORT, HOST, () => console.log(`HandShake server en http://${HOST}:${PORT} · datos en ${DATA_FILE}`));
}
module.exports = { server, db, flush };
